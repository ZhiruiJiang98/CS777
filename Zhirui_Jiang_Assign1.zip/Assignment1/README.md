# Assignment-1
Starter code for assignment 1
Use the lastname_name_Assignment_1.py file to submit your job to Google Cloud.
